import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createClassifier } from '../src/classification.js';

const data = JSON.parse(gunzipSync(readFileSync(new URL('../public/data/boundaries-overview.json.gz', import.meta.url))));
const classify = createClassifier(data.snapshots);
const feature = (name, authority = name) => ({ name, authority });

test('government labels and named polities are distinct from source-labelled cultures and foragers', () => {
  assert.equal(classify(feature('Roman Empire'), 100).layer, 'state');
  assert.equal(classify(feature('Rome'), -500).layer, 'state');
  assert.equal(classify(feature('Glades Culture'), -500).layer, 'cultural');
  assert.equal(classify(feature('Baltic tribes'), 1000).layer, 'cultural');
  assert.equal(classify(feature('West African cereal farmers'), 1000).layer, 'cultural');
  assert.equal(classify(feature('Saharan pastoral nomads'), -500).layer, 'cultural');
  for (const name of [
    'Australian aboriginal hunter-gatherers', 'Shellfish gatherers',
    'Plain bison hunters', 'Plateau fichers and hunter gatherers',
    'North American Pacific foraging, hunting and fishing peoples',
  ]) assert.equal(classify(feature(name), 1000).layer, 'hunter', name);
});

test('identity is not used to infer subsistence, statehood, or absence of government', () => {
  assert.equal(classify(feature('Ainu'), 1000).layer, 'cultural');
  assert.notEqual(classify(feature('Ainu'), 1000).layer, 'hunter');
  assert.equal(classify(feature('Example Confederacy'), 1000).layer, 'state');
  assert.equal(classify(feature('Example Tribe', 'United States'), 1900).layer, 'state');
  assert.equal(classify(feature('Czechs', 'Slavic tribes'), 800).layer, 'cultural');
  assert.equal(classify(feature('Unfamiliar group'), 1000).layer, 'unclassified');
  assert.equal(classify(feature('Unfamiliar area', 'Uncertain authority'), 1000).layer, 'unclassified');
});

test('modern-map authority inference is time-qualified, not projected into antiquity', () => {
  assert.equal(classify(feature('Canada'), 2000).layer, 'state');
  assert.equal(classify(feature('Canada'), -500).layer, 'unclassified');
  assert.equal(classify(feature('Western Sahara'), 2000).layer, 'unclassified');
});

test('real hunter-gatherer and cultural source features are separated without losing their labels', () => {
  const snapshot = data.snapshots.find(s => s.year === 1000);
  for (const [name, expected] of [
    ['Australian aboriginal hunter-gatherers', 'hunter'],
    ['Baltic tribes', 'cultural'],
    ['Byzantine Empire', 'state'],
  ]) {
    const original = snapshot.features.find(f => f.name === name);
    assert(original, `${name} exists in the source snapshot`);
    const before = JSON.stringify(original);
    const result = classify(original, snapshot.year);
    assert.equal(result.layer, expected);
    assert(result.basis.length > 10);
    assert.equal(JSON.stringify(original), before);
  }
});
