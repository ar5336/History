import { test, expect } from '@playwright/test';

async function ready(page) {
  await expect(page.locator('#loading')).toBeHidden();
  await expect(page.locator('#error')).toBeHidden();
  await page.waitForFunction(() => window.__chronos?.ready && !window.__chronos.sectionPending && window.__chronos.capTriangles > 0);
}

async function setRange(page, id, value) {
  await page.locator(`#${id}`).evaluate((input, value) => {
    input.value = String(value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}

test('real-data model, GPU scrubbing, filled arbitrary cuts, picking and isolation', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await page.goto('/');
  await ready(page);
  const initial = await page.evaluate(() => window.__chronos);
  expect(initial.triangles).toBeGreaterThan(10000);
  expect(initial.triangles).toBeLessThan(250000);
  expect(initial.draws).toBeLessThanOrEqual(8);
  expect(initial.geometryBytes).toBeLessThan(10_000_000);
  expect(initial.entities).toBeLessThan(initial.records);
  await setRange(page, 'year', 1620);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 1600 CE');
  expect(await page.evaluate(() => window.__chronos.modelId)).toBe(initial.modelId);
  await setRange(page, 'year', 2010);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 2010 CE');
  await setRange(page, 'year', 1650);
  await ready(page);
  const horizontalTriangles = await page.evaluate(() => window.__chronos.capTriangles);
  await page.locator('[data-mode=oblique]').click();
  await setRange(page, 'tilt', 0);
  await ready(page);
  expect(await page.evaluate(() => window.__chronos.capTriangles)).toBe(horizontalTriangles);
  await setRange(page, 'tilt', 35);
  await page.locator('[data-mode=time]').click();
  await ready(page);
  const canvas = page.locator('#scene canvas');
  const box = await canvas.boundingBox();
  let selected = false;
  for (const [x, y] of [[0.55, 0.53], [0.5, 0.6], [0.62, 0.6]]) {
    await canvas.click({ position: { x: box.width * x, y: box.height * y } });
    selected = await page.locator('#selection-actions').isVisible();
    if (selected) break;
  }
  expect(selected).toBe(true);
  await expect(page.locator('#inspector')).toContainText('Source snapshot');
  await page.locator('#isolate').click();
  await expect(page.locator('#isolate')).toHaveText('Show all polities');
  await page.locator('#clear-selection').click();
  for (const mode of ['longitude', 'latitude', 'oblique']) {
    await page.locator(`[data-mode=${mode}]`).click();
    await ready(page);
    expect(await page.evaluate(() => window.__chronos.mode)).toBe(mode);
    expect(await page.evaluate(() => window.__chronos.capVisible)).toBe(true);
    expect(await page.evaluate(() => window.__chronos.modelId)).toBe(initial.modelId);
  }
  await setRange(page, 'tilt', 62);
  await setRange(page, 'azimuth', 125);
  await ready(page);
  await page.locator('#section-only').click();
  await page.locator('#map-view').click();
  await page.locator('#flip').click();
  await ready(page);
  expect(await page.evaluate(() => window.__chronos.renderedTriangles)).toBeLessThan(initial.renderedTriangles);
  expect(errors).toEqual([]);
});

test('global/ancient coverage, source disclosure, and responsive controls', async ({ page }) => {
  await page.goto('/');
  await ready(page);
  await page.locator('#region').selectOption('world');
  await ready(page);
  const world = await page.evaluate(() => window.__chronos);
  expect(world.triangles).toBeLessThan(1_000_000);
  expect(world.draws).toBeLessThanOrEqual(8);
  await page.locator('#period').selectOption('ancient');
  await ready(page);
  await setRange(page, 'year', -323);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 323 BCE');
  await page.locator('#about-button').click();
  await expect(page.locator('#about')).toBeVisible();
  await expect(page.locator('#about')).toContainText('not known dates of conquest');
  await page.locator('#close-about').click();
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await expect(page.locator('#play')).toBeInViewport();
});
