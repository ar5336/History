import { test, expect } from '@playwright/test';

async function ready(page) {
  await expect(page.locator('#loading')).toBeHidden();
  await expect(page.locator('#error')).toBeHidden();
  await page.waitForFunction(() => window.__chronos?.ready && !window.__chronos.sectionPending && window.__chronos.capTriangles > 0);
}

async function setRange(page, id, value) {
  await page.locator(`#${id}`).evaluate((input, value) => {
    input.value = String(value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }, value);
}

test('real-data model, GPU scrubbing, filled arbitrary cuts, picking and isolation', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await page.goto('/');
  await ready(page);
  const initial = await page.evaluate(() => window.__chronos);
  expect(initial.triangles).toBeGreaterThan(10000);
  expect(initial.triangles).toBeLessThan(250000);
  expect(initial.draws).toBeLessThanOrEqual(14);
  expect(initial.geometryBytes).toBeLessThan(10_000_000);
  expect(initial.entities).toBeLessThan(initial.records);
  await setRange(page, 'year', 1620);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 1600 CE');
  expect(await page.evaluate(() => window.__chronos.modelId)).toBe(initial.modelId);
  await setRange(page, 'year', 2010);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 2010 CE');
  await setRange(page, 'year', 1650);
  await ready(page);
  const horizontalTriangles = await page.evaluate(() => window.__chronos.capTriangles);
  await page.locator('[data-mode=oblique]').click();
  await setRange(page, 'tilt', 0);
  await ready(page);
  expect(await page.evaluate(() => window.__chronos.capTriangles)).toBe(horizontalTriangles);
  await setRange(page, 'tilt', 35);
  await page.locator('[data-mode=time]').click();
  await ready(page);
  const canvas = page.locator('#scene canvas');
  const box = await canvas.boundingBox();
  let selected = false;
  for (const [x, y] of [[0.55, 0.53], [0.5, 0.6], [0.62, 0.6]]) {
    await canvas.click({ position: { x: box.width * x, y: box.height * y } });
    selected = await page.locator('#selection-actions').isVisible();
    if (selected) break;
  }
  expect(selected).toBe(true);
  await expect(page.locator('#inspector')).toContainText('Source snapshot');
  await page.locator('#isolate').click();
  await expect(page.locator('#isolate')).toHaveText('Show all polities');
  await page.locator('#clear-selection').click();
  for (const mode of ['longitude', 'latitude', 'oblique']) {
    await page.locator(`[data-mode=${mode}]`).click();
    await ready(page);
    expect(await page.evaluate(() => window.__chronos.mode)).toBe(mode);
    expect(await page.evaluate(() => window.__chronos.capVisible)).toBe(true);
    expect(await page.evaluate(() => window.__chronos.modelId)).toBe(initial.modelId);
  }
  await setRange(page, 'tilt', 62);
  await setRange(page, 'azimuth', 125);
  await ready(page);
  await page.locator('#section-only').click();
  await page.locator('#map-view').click();
  await page.locator('#flip').click();
  await ready(page);
  expect(await page.evaluate(() => window.__chronos.renderedTriangles)).toBeLessThan(initial.renderedTriangles);
  expect(errors).toEqual([]);
});

test('global/ancient coverage, source disclosure, and responsive controls', async ({ page }) => {
  await page.goto('/');
  await ready(page);
  await page.locator('#region').selectOption('world');
  await ready(page);
  const world = await page.evaluate(() => window.__chronos);
  expect(world.triangles).toBeLessThan(1_000_000);
  expect(world.draws).toBeLessThanOrEqual(14);
  await page.locator('#period').selectOption('ancient');
  await ready(page);
  await setRange(page, 'year', -323);
  await ready(page);
  await expect(page.locator('#snapshot-label')).toHaveText('Source map · 323 BCE');
  await page.locator('#about-button').click();
  await expect(page.locator('#about')).toBeVisible();
  await expect(page.locator('#about')).toContainText('not known dates of conquest');
  await page.locator('#close-about').click();
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await expect(page.locator('#play')).toBeInViewport();
});

test('historical layers hide and blend both volumes and sections without rebuilding geometry', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await page.goto('/');
  await ready(page);
  await page.locator('#region').selectOption('world');
  await ready(page);
  await setRange(page, 'year', 1000);
  await ready(page);
  const initial = await page.evaluate(() => window.__chronos);
  expect(initial.layers.hunter.triangles).toBeGreaterThan(0);
  expect(initial.layerDisplay.hunter).toBe('hidden');
  expect(initial.layerRendering.hunter.volumeVisible).toBe(false);
  expect(initial.layerRendering.hunter.capVisible).toBe(false);
  await page.waitForFunction(() => window.__chronos.idle);
  const hiddenImage = await page.locator('#scene canvas').screenshot();
  await page.locator('#entity-search').fill('Australian aboriginal hunter-gatherers');
  await expect(page.locator('#search-results')).toContainText('No matching authority');
  await page.locator('#layer-hunter').selectOption('transparent');
  await expect(page.locator('#search-results button')).toContainText('Hunter-gatherer areas');
  await page.waitForFunction(() => window.__chronos.layerRendering.hunter.volumeVisible);
  let state = await page.evaluate(() => window.__chronos);
  expect(state.modelId).toBe(initial.modelId);
  expect(state.geometryBytes).toBe(initial.geometryBytes);
  expect(state.layerRendering.hunter.capVisible).toBe(true);
  expect(state.layerRendering.hunter.transparent).toBe(true);
  expect(state.layerRendering.hunter.depthWrite).toBe(false);
  expect(state.layerRendering.hunter.opacity).toBeCloseTo(0.3);
  expect(state.layerRendering.state.transparent).toBe(false);
  await page.waitForFunction(() => window.__chronos.idle);
  const transparentImage = await page.locator('#scene canvas').screenshot();
  expect(transparentImage.equals(hiddenImage)).toBe(false);
  await page.locator('#layer-hunter').selectOption('solid');
  await page.waitForFunction(() => window.__chronos.layerRendering.hunter.opacity === 1);
  state = await page.evaluate(() => window.__chronos);
  expect(state.layerRendering.hunter.transparent).toBe(false);
  expect(state.layerRendering.hunter.depthWrite).toBe(true);
  await page.waitForFunction(() => window.__chronos.idle);
  const solidImage = await page.locator('#scene canvas').screenshot();
  expect(solidImage.equals(transparentImage)).toBe(false);
  await page.locator('#layer-hunter').selectOption('hidden');
  await page.waitForFunction(() => window.__chronos.layerDisplay.hunter === 'hidden' && window.__chronos.idle);
  expect((await page.locator('#scene canvas').screenshot()).equals(hiddenImage)).toBe(true);
  await page.locator('#layer-hunter').selectOption('transparent');
  await page.locator('#search-results button').click();
  await expect(page.locator('#inspector')).toContainText('Hunter-gatherer areas');
  await setRange(page, 'context-opacity', 0.6);
  await page.waitForFunction(() => window.__chronos.layerRendering.hunter.opacity === 0.6);
  expect(await page.evaluate(() => window.__chronos.layerRendering.state.opacity)).toBe(1);
  await page.locator('[data-mode=oblique]').click();
  await ready(page);
  await page.locator('#section-only').click();
  await page.waitForFunction(() => !window.__chronos.layerRendering.hunter.volumeVisible);
  expect(await page.evaluate(() => window.__chronos.layerRendering.hunter.capVisible)).toBe(true);
  await page.locator('#layer-hunter').selectOption('hidden');
  await expect(page.locator('#selection-actions')).toBeHidden();
  await page.waitForFunction(() => !window.__chronos.layerRendering.hunter.capVisible);
  expect(await page.evaluate(() => window.__chronos.modelId)).toBe(initial.modelId);
  await page.locator('#layer-cultural').selectOption('hidden');
  await page.locator('#layer-unclassified').selectOption('hidden');
  await expect(page.locator('#classification-help')).toBeVisible();
  await page.locator('#classification-help').click();
  await expect(page.locator('#about')).toContainText('no state/non-state or subsistence classification field');
  expect(errors).toEqual([]);
});
