import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { clipPolygon, triangulate, snapshotAt, planeFor, signedDistance, sectionOfPrism } from '../src/geometry.js';

const square = (x, y, size) => [[x, y], [x + size, y], [x + size, y + size], [x, y + size], [x, y]];
function area(shape) {
  let sum = 0;
  for (let i = 0; i < shape.indices.length; i += 3) {
    const [a, b, c] = shape.indices.slice(i, i + 3).map(n => [shape.flat[n * 2], shape.flat[n * 2 + 1]]);
    sum += Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
  }
  return sum;
}

test('snapshot holds change exactly at source dates, not at arbitrary intermediate years', () => {
  const snapshots = [-500, -1, 100, 1000, 2010].map(year => ({ year }));
  assert.equal(snapshotAt(snapshots, 1620).year, 1000);
  assert.equal(snapshotAt(snapshots, 100).year, 100);
  assert.equal(snapshotAt(snapshots, 2010).year, 2010);
  assert.equal(snapshotAt(snapshots, -200).year, -500);
  assert.equal(snapshotAt(snapshots, -501), null);
  assert.equal(snapshotAt(snapshots, 2011), null);
});

test('regional clipping preserves holes and splits disconnected pieces', () => {
  const polygon = [square(0, 0, 10), square(3, 3, 4).reverse()];
  const clipped = clipPolygon(polygon, [1, 1, 9, 9]);
  assert.equal(clipped.length, 1);
  assert.equal(clipped[0].length, 2);
  assert.equal(area(triangulate(clipped[0], [1, 1, 9, 9])), 48);
  const uShape = [[[0, 0], [10, 0], [10, 10], [7, 10], [7, 3], [3, 3], [3, 10], [0, 10], [0, 0]]];
  assert.equal(clipPolygon(uShape, [0, 5, 10, 9]).length, 2);
});

test('antimeridian polygons split at the seam instead of spanning the map', () => {
  const polygon = [[[170, -10], [-170, -10], [-170, 10], [170, 10], [170, -10]]];
  const clipped = clipPolygon(polygon, [-180, -60, 180, 85]);
  assert.equal(clipped.length, 2);
  assert.equal(clipped.reduce((sum, p) => sum + area(triangulate(p, [-180, -60, 180, 85])), 0), 400);
});

test('cut-plane directions retain the documented half-spaces, including reversal', () => {
  const dimensions = { width: 100, depth: 80, height: 100, start: 1000, end: 2000 };
  const time = planeFor({ mode: 'time', position: 1500 }, dimensions);
  assert(signedDistance([0, 20, 0], time) > 0);
  assert(signedDistance([0, 80, 0], time) < 0);
  const reversed = planeFor({ mode: 'time', position: 1500, reverse: true }, dimensions);
  assert(signedDistance([0, 20, 0], reversed) < 0);
  assert(signedDistance([-20, 0, 0], planeFor({ mode: 'longitude', position: 0.5 }, dimensions)) > 0);
  assert(signedDistance([0, 0, 20], planeFor({ mode: 'latitude', position: 0.5 }, dimensions)) > 0);
});

test('filled prism sections lie on arbitrary planes and do not bridge holes', () => {
  const triangle = [[0, 0], [10, 0], [0, 10]];
  const planes = [[0, -1, 0, 5], [-1, 0, 0, 2], [0.6, -0.8, 0, 3], [0, -1, 0, 0]];
  for (const plane of planes) {
    const section = sectionOfPrism(triangle, 0, 10, plane);
    assert(section.length >= 3);
    for (const p of section) {
      assert(Math.abs(signedDistance(p, plane)) < 1e-6);
      assert(p[0] >= -1e-6 && p[2] >= -1e-6 && p[0] + p[2] <= 10 + 1e-6);
      assert(p[1] >= 0 && p[1] <= 10);
    }
  }
  assert.deepEqual(sectionOfPrism(triangle, 0, 10, [0, -1, 0, 20]), []);
  const donut = triangulate([square(0, 0, 10), square(3, 3, 4).reverse()], [0, 0, 10, 10]);
  let capArea = 0;
  for (let i = 0; i < donut.indices.length; i += 3) {
    const tri = donut.indices.slice(i, i + 3).map(n => [donut.flat[n * 2], donut.flat[n * 2 + 1]]);
    const section = sectionOfPrism(tri, 0, 10, [0, -1, 0, 5]);
    capArea += area(triangulate([section.map(p => [p[0], p[2]])], [0, 0, 0, 0]));
  }
  assert.equal(capArea, 84);
});

test('bundled data match provenance hashes and include real, finite historical polygons', () => {
  const manifest = JSON.parse(readFileSync(new URL('../public/data/manifest.json', import.meta.url)));
  for (const entry of [manifest.data, manifest.overview]) {
    const bytes = readFileSync(new URL(`../public/data/${entry.file}`, import.meta.url));
    assert.equal(createHash('sha256').update(bytes).digest('hex'), entry.sha256);
    const data = JSON.parse(gunzipSync(bytes));
    assert.equal(data.snapshots.length, 44);
    assert.equal(data.snapshots[0].year, -500);
    assert.equal(data.snapshots.at(-1).year, 2010);
    for (const snapshot of data.snapshots) {
      for (const feature of snapshot.features) {
        assert(Array.isArray(feature.polygons));
        for (const polygon of feature.polygons) {
          for (const ring of polygon) {
            assert(ring.length >= 4);
            assert.deepEqual(ring[0], ring.at(-1));
            for (const [lon, lat] of ring) assert(Number.isFinite(lon) && Number.isFinite(lat) && Math.abs(lat) <= 90);
          }
        }
      }
    }
  }
});
