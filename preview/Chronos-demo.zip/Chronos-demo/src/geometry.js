import earcut from 'earcut';
import polygonClipping from 'polygon-clipping';

export const REGIONS = {
  mediterranean: { label: 'Europe & Mediterranean', bounds: [-18, 15, 58, 65] },
  world: { label: 'World · 60°S–85°N', bounds: [-180, -60, 180, 85] },
  asia: { label: 'East Asia', bounds: [65, -12, 150, 62] },
  americas: { label: 'The Americas', bounds: [-170, -57, -30, 75] },
};

export function yearLabel(year) {
  return year < 0 ? `${-year} BCE` : `${year} CE`;
}

export function snapshotAt(snapshots, year) {
  let low = 0;
  let high = snapshots.length - 1;
  if (year < snapshots[0].year || year > snapshots[high].year) return null;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (snapshots[mid].year <= year) low = mid;
    else high = mid - 1;
  }
  return snapshots[low];
}

// Unwrap first, then split at the map seam, rather than stretching Russia across the world.
export function clipPolygon(polygon, bounds) {
  const [west, south, east, north] = bounds;
  const unwrapped = polygon.map((ring, ringIndex) => {
    let previous = ring[0][0];
    const result = ring.map(([lon, lat]) => {
      while (lon - previous > 180) lon -= 360;
      while (lon - previous < -180) lon += 360;
      previous = lon;
      return [lon, lat];
    });
    if (ringIndex && result.length) {
      const shift = 360 * Math.round((polygon[0][0][0] - result[0][0]) / 360);
      for (const point of result) point[0] += shift;
    }
    return result;
  });
  const xs = unwrapped[0].map(p => p[0]);
  const min = Math.min(...xs);
  const max = Math.max(...xs);
  const ys = unwrapped[0].map(p => p[1]);
  if (Math.max(...ys) < south || Math.min(...ys) > north) return [];
  const box = [[[west, south], [east, south], [east, north], [west, north], [west, south]]];
  const result = [];
  const first = Math.ceil((west - max) / 360);
  const last = Math.floor((east - min) / 360);
  for (let k = first; k <= last; k++) {
    const shifted = unwrapped.map(r => r.map(([x, y]) => [x + k * 360, y]));
    result.push(...polygonClipping.intersection([shifted], [box]));
  }
  return result;
}

export function triangulate(polygon, bounds) {
  const [west, south, east, north] = bounds;
  const flat = [];
  const holes = [];
  const rings = [];
  for (let i = 0; i < polygon.length; i++) {
    const ring = polygon[i];
    const end = ring.length > 1 && ring[0][0] === ring.at(-1)[0] && ring[0][1] === ring.at(-1)[1]
      ? ring.length - 1 : ring.length;
    if (end < 3) continue;
    if (i) holes.push(flat.length / 2);
    const start = flat.length / 2;
    for (let j = 0; j < end; j++) flat.push(ring[j][0] - (west + east) / 2, (south + north) / 2 - ring[j][1]);
    rings.push({ start, count: end });
  }
  return { flat, rings, indices: earcut(flat, holes, 2) };
}

export function colorFor(name) {
  let hash = 2166136261;
  for (const c of name) hash = Math.imul(hash ^ c.charCodeAt(0), 16777619);
  const palette = [
    [107, 184, 176], [202, 158, 100], [134, 155, 201], [181, 133, 161],
    [157, 177, 115], [207, 135, 113], [120, 166, 189], [180, 165, 203],
    [185, 183, 135], [112, 166, 137], [201, 140, 136], [151, 166, 178],
    [202, 179, 143], [145, 145, 190], [170, 190, 163], [198, 155, 177],
  ];
  return palette[(hash >>> 0) % palette.length];
}

export function planeFor({ mode, position, tilt = 25, azimuth = 0, reverse = false }, dimensions) {
  const { width, depth, height, start, end } = dimensions;
  let normal;
  let point;
  if (mode === 'time') {
    normal = [0, -1, 0];
    point = [0, (position - start) / (end - start) * height, 0];
  } else if (mode === 'longitude') {
    normal = [-1, 0, 0];
    point = [(position - 0.5) * width, 0, 0];
  } else if (mode === 'latitude') {
    normal = [0, 0, 1];
    point = [0, 0, (0.5 - position) * depth];
  } else {
    const t = tilt * Math.PI / 180;
    const a = azimuth * Math.PI / 180;
    normal = [Math.sin(t) * Math.cos(a), -Math.cos(t), Math.sin(t) * Math.sin(a)];
    point = [0, position * height, 0];
  }
  if (reverse) normal = normal.map(n => -n);
  return [...normal, -normal.reduce((sum, n, i) => sum + n * point[i], 0)];
}

export function signedDistance(point, plane) {
  return point[0] * plane[0] + point[1] * plane[1] + point[2] * plane[2] + plane[3];
}

const prismEdges = [[0, 1], [1, 2], [2, 0], [3, 4], [4, 5], [5, 3], [0, 3], [1, 4], [2, 5]];

// A triangular prism is convex: its planar section is a small convex polygon.
// Tiling the original triangulation preserves concavities and holes without contour stitching.
export function sectionOfPrism(triangle, bottom, top, plane) {
  const points = [
    ...triangle.map(([x, z]) => [x, bottom, z]),
    ...triangle.map(([x, z]) => [x, top, z]),
  ];
  const distances = points.map(p => signedDistance(p, plane));
  if (Math.min(...distances) > 1e-7 || Math.max(...distances) < -1e-7) return [];
  const section = [];
  const add = p => {
    if (!section.some(q => q.every((v, i) => Math.abs(v - p[i]) < 1e-6))) section.push(p);
  };
  for (const [a, b] of prismEdges) {
    const da = distances[a];
    const db = distances[b];
    if (Math.abs(da) < 1e-7) add(points[a]);
    if (da * db < -1e-14) {
      const t = da / (da - db);
      add(points[a].map((v, i) => v + (points[b][i] - v) * t));
    }
    if (Math.abs(db) < 1e-7) add(points[b]);
  }
  if (section.length < 3) return [];
  const center = section[0].map((_, i) => section.reduce((sum, p) => sum + p[i], 0) / section.length);
  const n = plane.slice(0, 3);
  const seed = Math.abs(n[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const u = cross(n, seed);
  const v = cross(n, u);
  const angle = p => {
    const d = p.map((c, i) => c - center[i]);
    return Math.atan2(d.reduce((s, c, i) => s + c * v[i], 0), d.reduce((s, c, i) => s + c * u[i], 0));
  };
  section.sort((a, b) => angle(a) - angle(b));
  return section;
}
