import { BufferGeometry, BufferAttribute } from 'three';
import { MeshBVH } from 'three-mesh-bvh';
import { clipPolygon, triangulate, colorFor, sectionOfPrism, snapshotAt } from './geometry.js';

class Builder {
  constructor(Type, capacity = 4096) {
    this.Type = Type;
    this.buffer = new Type(capacity);
    this.length = 0;
  }
  push(...values) {
    if (this.length + values.length > this.buffer.length) {
      const next = new this.Type(Math.max(this.buffer.length * 2, this.length + values.length));
      next.set(this.buffer);
      this.buffer = next;
    }
    this.buffer.set(values, this.length);
    this.length += values.length;
  }
  finish() { return this.buffer.slice(0, this.length); }
}

let loadedQuality;
let dataset;
let chunks = [];
let currentModel;

async function load(quality) {
  if (loadedQuality === quality) return dataset;
  self.postMessage({ type: 'progress', message: `Loading ${quality === 'detail' ? 'detailed' : 'overview'} historical boundaries…` });
  const file = quality === 'detail' ? 'boundaries.json.gz' : 'boundaries-overview.json.gz';
  const response = await fetch(`${import.meta.env.BASE_URL}data/${file}`);
  if (!response.ok) throw new Error(`Boundary data: HTTP ${response.status}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes[0] === 0x1f && bytes[1] === 0x8b) {
    if (typeof DecompressionStream === 'undefined') throw new Error('This browser needs gzip DecompressionStream support. Use a current Chrome, Firefox, Edge or Safari.');
    dataset = await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).json();
  } else {
    // Servers such as Vite already decode .gz assets through Content-Encoding.
    dataset = JSON.parse(new TextDecoder().decode(bytes));
  }
  loadedQuality = quality;
  return dataset;
}

function meshBuffers() {
  return {
    positions: new Builder(Float32Array),
    colors: new Builder(Uint8Array),
    entityIds: new Builder(Uint16Array),
    recordIds: new Builder(Uint16Array),
    indices: new Builder(Uint32Array),
  };
}

function vertex(buffers, x, y, z, color, entityId, recordId) {
  buffers.positions.push(x, y, z);
  buffers.colors.push(...color);
  buffers.entityIds.push(entityId);
  buffers.recordIds.push(recordId);
}

function finish(buffers) {
  return Object.fromEntries(Object.entries(buffers).map(([key, value]) => [key, value.finish()]));
}

async function build(config, requestId) {
  const started = performance.now();
  const data = await load(config.quality);
  self.postMessage({ type: 'progress', message: 'Clipping polygons, triangulating territories and building the picking index…' });
  const { bounds, start, end } = config;
  if (!(start < end)) throw new Error('Start year must precede end year.');
  const width = bounds[2] - bounds[0];
  const depth = bounds[3] - bounds[1];
  const height = width * 0.9;
  const dimensions = { width, depth, height, start, end, bounds };
  const toY = year => (year - start) / (end - start) * height;
  const volume = meshBuffers();
  const land = meshBuffers();
  const entities = [];
  const entitiesByName = new Map();
  const records = [];
  const newChunks = [];
  const entityFor = name => {
    if (!entitiesByName.has(name)) {
      const id = entities.length + 1;
      entitiesByName.set(name, id);
      entities.push({ id, name, color: colorFor(name) });
    }
    return entitiesByName.get(name);
  };

  for (let s = 0; s < data.snapshots.length; s++) {
    const snapshot = data.snapshots[s];
    const next = data.snapshots[s + 1]?.year ?? snapshot.year;
    if (next <= start && snapshot.year !== start || snapshot.year > end) continue;
    const bottom = toY(Math.max(start, snapshot.year));
    const top = toY(Math.min(end, next));
    for (const feature of snapshot.features) {
      if (!feature.name) continue;
      let entityId;
      let color;
      let recordId;
      for (const sourcePolygon of feature.polygons) {
        for (const polygon of clipPolygon(sourcePolygon, bounds)) {
          const shape = triangulate(polygon, bounds);
          if (!shape.indices.length) continue;
          if (recordId === undefined) {
            entityId = entityFor(feature.authority);
            color = entities[entityId - 1].color;
            recordId = records.length;
            if (recordId >= 65535) throw new Error('Too many features for the prototype record buffer.');
            records.push({
              name: feature.name, authority: feature.authority, precision: feature.precision,
              year: snapshot.year, until: next, entityId,
            });
          }
          let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
          for (let i = 0; i < shape.flat.length; i += 2) {
            minX = Math.min(minX, shape.flat[i]); maxX = Math.max(maxX, shape.flat[i]);
            minZ = Math.min(minZ, shape.flat[i + 1]); maxZ = Math.max(maxZ, shape.flat[i + 1]);
          }
          newChunks.push({ ...shape, bottom, top, recordId, entityId, color, year: snapshot.year, until: next, minX, maxX, minZ, maxZ });
          if (top <= bottom) continue;
          const offset = volume.positions.length / 3;
          const count = shape.flat.length / 2;
          for (const y of [bottom, top]) {
            for (let i = 0; i < shape.flat.length; i += 2) {
              vertex(volume, shape.flat[i], y, shape.flat[i + 1], color, entityId, recordId);
            }
          }
          for (let i = 0; i < shape.indices.length; i += 3) {
            const [a, b, c] = shape.indices.slice(i, i + 3);
            volume.indices.push(offset + c, offset + b, offset + a);
            volume.indices.push(offset + count + a, offset + count + b, offset + count + c);
          }
          for (const ring of shape.rings) {
            for (let i = 0; i < ring.count; i++) {
              const a = offset + ring.start + i;
              const b = offset + ring.start + (i + 1) % ring.count;
              volume.indices.push(a, b, b + count, a, b + count, a + count);
            }
          }
        }
      }
    }
  }

  // The neutral footprint is context from the final source map, not a claim about ancient coastlines.
  for (const feature of data.snapshots.at(-1).features) {
    for (const sourcePolygon of feature.polygons) {
      for (const polygon of clipPolygon(sourcePolygon, bounds)) {
        const shape = triangulate(polygon, bounds);
        const offset = land.positions.length / 3;
        for (let i = 0; i < shape.flat.length; i += 2) vertex(land, shape.flat[i], -height * 0.008, shape.flat[i + 1], [51, 65, 77], 0, 0);
        for (const i of shape.indices) land.indices.push(offset + i);
      }
    }
  }

  const buffers = finish(volume);
  const landBuffers = finish(land);
  const geometry = new BufferGeometry();
  geometry.setAttribute('position', new BufferAttribute(buffers.positions, 3));
  geometry.setIndex(new BufferAttribute(buffers.indices, 1));
  const bvh = new MeshBVH(geometry, { maxLeafSize: 12 });
  const serialized = MeshBVH.serialize(bvh);
  buffers.indices = geometry.index.array;
  chunks = newChunks;
  currentModel = dimensions;
  const stats = {
    triangles: buffers.indices.length / 3, vertices: buffers.positions.length / 3,
    entities: entities.length, records: records.length,
    snapshots: data.snapshots.filter(s => s.year >= start && s.year <= end).length,
    buildMs: Math.round(performance.now() - started),
    geometryBytes: Object.values(buffers).reduce((sum, b) => sum + b.byteLength, 0),
  };
  const transfers = [...Object.values(buffers), ...Object.values(landBuffers)].map(a => a.buffer);
  transfers.push(...serialized.roots);
  self.postMessage({ type: 'model', requestId, buffers, landBuffers, bvh: serialized, entities, records, dimensions, stats,
    sourceYears: data.snapshots.map(s => s.year) },
    [...new Set(transfers)]);
  geometry.dispose();
}

function slice(config, requestId) {
  if (!currentModel) throw new Error('No model is loaded.');
  const started = performance.now();
  const { plane, mode, year, modelId } = config;
  const horizontal = Math.abs(plane[0]) + Math.abs(plane[2]) < 1e-8;
  const sectionYear = horizontal
    ? currentModel.start + (-plane[3] / plane[1]) / currentModel.height * (currentModel.end - currentModel.start)
    : year;
  const sourceYear = snapshotAt(dataset.snapshots, Math.round(sectionYear * 1e6) / 1e6)?.year;
  const buffers = meshBuffers();
  const visible = new Set();
  for (const chunk of chunks) {
    if (horizontal) {
      if (chunk.year !== sourceYear) continue;
      const y = (sectionYear - currentModel.start) / (currentModel.end - currentModel.start) * currentModel.height;
      const offset = buffers.positions.length / 3;
      for (let i = 0; i < chunk.flat.length; i += 2) vertex(buffers, chunk.flat[i], y, chunk.flat[i + 1], chunk.color, chunk.entityId, chunk.recordId);
      for (const i of chunk.indices) buffers.indices.push(offset + i);
      visible.add(chunk.entityId);
      continue;
    }
    if (chunk.top <= chunk.bottom) continue;
    const minDistance = plane[3] + plane[0] * (plane[0] >= 0 ? chunk.minX : chunk.maxX)
      + plane[1] * (plane[1] >= 0 ? chunk.bottom : chunk.top) + plane[2] * (plane[2] >= 0 ? chunk.minZ : chunk.maxZ);
    const maxDistance = plane[3] + plane[0] * (plane[0] >= 0 ? chunk.maxX : chunk.minX)
      + plane[1] * (plane[1] >= 0 ? chunk.top : chunk.bottom) + plane[2] * (plane[2] >= 0 ? chunk.maxZ : chunk.minZ);
    if (minDistance > 1e-7 || maxDistance < -1e-7) continue;
    for (let i = 0; i < chunk.indices.length; i += 3) {
      const triangle = chunk.indices.slice(i, i + 3).map(index => [chunk.flat[index * 2], chunk.flat[index * 2 + 1]]);
      const section = sectionOfPrism(triangle, chunk.bottom, chunk.top, plane);
      if (!section.length) continue;
      const offset = buffers.positions.length / 3;
      for (const [x, y, z] of section) vertex(buffers, x, y, z, chunk.color, chunk.entityId, chunk.recordId);
      for (let j = 1; j < section.length - 1; j++) buffers.indices.push(offset, offset + j, offset + j + 1);
      visible.add(chunk.entityId);
    }
  }
  const result = finish(buffers);
  self.postMessage({ type: 'slice', requestId, modelId, mode, year, sourceYear, buffers: result, visible: [...visible], sliceMs: Math.round(performance.now() - started) },
    Object.values(result).map(a => a.buffer));
}

let chain = Promise.resolve();
self.onmessage = ({ data }) => {
  chain = chain.then(async () => {
    if (data.type === 'build') await build(data.config, data.requestId);
    else if (data.type === 'slice') slice(data.config, data.requestId);
  }).catch(error => {
    console.error(error);
    self.postMessage({ type: 'error', requestId: data.requestId, message: error.message });
  });
};
