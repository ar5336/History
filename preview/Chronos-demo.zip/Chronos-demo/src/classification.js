export const LAYERS = {
  state: { label: 'States / governments', defaultDisplay: 'solid' },
  cultural: { label: 'Tribal / cultural areas', defaultDisplay: 'transparent' },
  hunter: { label: 'Hunter-gatherer areas', defaultDisplay: 'hidden' },
  unclassified: { label: 'Unclassified labels', defaultDisplay: 'transparent' },
};

const normalize = value => value.normalize('NFKC').toLocaleLowerCase('en').trim();
const knownPolities = new Set([
  'Rome', 'Carthage', 'France', 'England', 'Scotland', 'Spain', 'Portugal', 'Venice',
  'Castilla', 'Aragón', 'León', 'Navarre', 'Denmark', 'Sweden', 'Norway', 'Denmark-Norway',
  'Poland', 'Hungary', 'Croatia', 'Serbia', 'Armenia', 'Georgia', 'Kyivan Rus',
  'Egypt', 'Persia', 'China', 'Japan', 'Korea', 'Tibet', 'Liao', 'Xixia', 'Nan Chao',
  'Champa', 'Dvaravati', 'Annam', 'Orissa', 'Kalinga', 'Palas', 'Pratiharas', 'Senas',
  'Kanem', 'Alwa', 'Makkura', 'Takrur', 'Ghana', 'Mali', 'Great Zimbabwe',
  'Meroe', 'Saba', 'Magadha', 'Kosala', 'Avanti', 'Gandhāra', 'Kuru', 'Kasi',
  'Malla', 'Pancala', 'Surasena', 'Vatsa', 'Simhala', 'Muscat', 'Yemen',
  'Netherlands', 'Spanish Habsburg', 'Prussia', 'USSR', 'UK', 'Great Britain',
  'United Provinces', 'Đại Việt', 'Ethiopia', 'Oyo', 'Hadramaut', 'Ceylon',
  'Lunda', 'Ayutthaya', 'Kongo', 'Congo', 'Cambodia', 'Luba', 'Portuguese Guinea',
  'Benin', 'Songhai', 'Kanem-Bornu', 'Cyprus', 'Morocco', 'Oman', 'Aceh', 'Wadai', 'Darfur',
].map(normalize));
const culturalLabels = new Set([
  'Ainu', 'Austronesians', 'Paleo-Inuit', 'Saami', 'Samis', 'Khoisan', 'Guanches',
  'Curonians', 'Boii', 'Illyrians', 'Etrurians', 'Sabini', 'Samnites', 'Olmec',
  'Chavin', 'Chinchoros', 'Chorrera', 'Arawaks', 'Athabaskan', 'Boethuk', 'Dorset',
  'Guanahatabeyes', 'Innu', 'Karelians', 'Polynesians', 'Taino', 'Thule',
].map(normalize));

const stateWords = /\b(empire|kingdoms?|caliphates?|sultanates?|emirates?|khanates?|khaganates?|republics?|duch(?:y|ies)|dynast(?:y|ies)|city[- ]states?|states?|commonwealth|confederac(?:y|ies)|confederation|principality|imperial)\b/;
const hunterWords = /\b(hunter|hunters|hunting|gatherers?|foraging|foragers?|fichers|fishers)\b/;
const culturalWords = /\b(tribes?|tribal|cultures?|peoples|nomads?|nomadic|pastoralists?|pastoral|farmers?|farming)\b/;

// The upstream maps have no entity-type field. Unrecognized labels stay unclassified.
export function createClassifier(snapshots) {
  const modernAuthorities = new Set(snapshots.at(-1).features
    .filter(f => f.name && f.authority && f.authority !== 'Western Sahara')
    .map(f => normalize(f.authority)));
  return (feature, year) => {
    const authority = normalize(feature.authority || feature.name || '');
    const name = normalize(feature.name || '');
    const stateBasis = label => {
      if (stateWords.test(label)) return 'Explicit state/polity term in source label';
      if (knownPolities.has(label)) return 'Curated named-polity display rule';
      if (year >= 1878 && modernAuthorities.has(label)) return 'Modern political-map authority label (1878 onward)';
      return null;
    };
    // A named governing authority takes precedence over a cultural feature name.
    const authorityBasis = stateBasis(authority);
    if (authorityBasis) return { layer: 'state', basis: authorityBasis };
    if (hunterWords.test(authority) || hunterWords.test(name)) {
      return { layer: 'hunter', basis: 'Source explicitly labels hunting, gathering, fishing or foraging' };
    }
    if (culturalWords.test(authority) || culturalWords.test(name) || culturalLabels.has(authority)) {
      return { layer: 'cultural', basis: 'Cultural, tribal, subsistence or broad people-label display rule' };
    }
    // A state-looking feature inside a broader cultural authority is not promoted to a state.
    if (!authority || authority === name) {
      const basis = stateBasis(name);
      if (basis) return { layer: 'state', basis };
    }
    return { layer: 'unclassified', basis: 'Insufficient label evidence; not assumed to be a state' };
  };
}
