import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { MeshBVH, acceleratedRaycast } from 'three-mesh-bvh';
import { REGIONS, yearLabel, planeFor, signedDistance, snapshotAt } from './geometry.js';
import './style.css';

const $ = id => document.getElementById(id);
const icon = {
  play: '<svg viewBox="0 0 24 24"><path d="m9 5 11 7-11 7Z"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14"/></svg>',
  reset: '<svg viewBox="0 0 24 24"><path d="M5 8a8 8 0 1 1-1 7M5 3v6h6"/></svg>',
  map: '<svg viewBox="0 0 24 24"><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Zm6-3v15m6-12v15"/></svg>',
  orbit: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="12" rx="10" ry="5" transform="rotate(-35 12 12)"/><circle cx="12" cy="12" r="3"/></svg>',
};

$('app').innerHTML = `
  <header class="header">
    <a class="brand" href="./" aria-label="Chronos home">
      <svg viewBox="0 0 32 36"><path d="m16 2 14 8-14 8L2 10Zm-14 16 14 8 14-8M2 26l14 8 14-8"/></svg>
      <span>CHRONOS<small>A SPACETIME ATLAS</small></span>
    </a>
    <div class="header-description">Geography, given another dimension.</div>
    <button id="about-button" class="text-button">Data & method <span>↗</span></button>
  </header>
  <main>
    <aside class="sidebar">
      <div class="eyebrow"><span class="live-dot"></span> HISTORICAL BOUNDARIES / 01</div>
      <h1>The shape<br>of time.</h1>
      <p class="intro">Territories become volumes.<br>Cut through them to find a moment.</p>
      <section class="control-section">
        <h2><span>01</span> Field of view</h2>
        <label for="region">Geography</label>
        <select id="region">${Object.entries(REGIONS).map(([key, r]) => `<option value="${key}">${r.label}</option>`).join('')}</select>
        <div class="field-row">
          <div><label for="period">Time window</label><select id="period">
            <option value="medieval">1000 – 2010 CE</option><option value="ancient">500 BCE – 1000 CE</option>
            <option value="modern">1700 – 2010 CE</option><option value="all">500 BCE – 2010 CE</option>
          </select></div>
          <div><label for="quality">Geometry</label><select id="quality"><option value="overview">Fast</option><option value="detail">Detailed</option></select></div>
        </div>
      </section>
      <section class="control-section">
        <h2><span>02</span> Cutting plane</h2>
        <div class="segments" role="group" aria-label="Cutting plane orientation">
          <button data-mode="time" class="active" aria-pressed="true">Time</button>
          <button data-mode="longitude" aria-pressed="false">Lon</button>
          <button data-mode="latitude" aria-pressed="false">Lat</button>
          <button data-mode="oblique" aria-pressed="false">Oblique</button>
        </div>
        <div id="spatial-controls" hidden><label for="spatial-position" class="range-label">Plane position <output id="spatial-value"></output></label>
          <input id="spatial-position" type="range" min="0" max="1" step="0.002" value="0.5">
        </div>
        <div id="oblique-controls" hidden>
          <label for="tilt" class="range-label">Tilt <output id="tilt-value">35°</output></label>
          <input id="tilt" type="range" min="0" max="90" value="35">
          <label for="azimuth" class="range-label">Bearing <output id="azimuth-value">0°</output></label>
          <input id="azimuth" type="range" min="0" max="360" value="0">
        </div>
        <label class="toggle"><span>Clip volume</span><input id="clip" type="checkbox" checked><span class="switch"></span></label>
        <label class="toggle"><span>Show cutting plane</span><input id="show-plane" type="checkbox" checked><span class="switch"></span></label>
        <div class="button-pair"><button id="flip">Reverse cut</button><button id="section-only" aria-pressed="false">Section only</button></div>
        <p id="cut-description" class="control-note">Horizontal cut. Earlier time is retained below the plane.</p>
      </section>
      <section class="control-section selection">
        <h2><span>03</span> Territory inspector</h2>
        <div id="inspector"><p class="empty-selection">Select a territory in the model<br>to inspect its source snapshot.</p></div>
        <div class="search-wrap"><label for="entity-search">Find a polity / authority</label>
          <input id="entity-search" type="search" placeholder="e.g. Ottoman Empire" autocomplete="off" disabled>
          <div id="search-results" hidden></div>
        </div>
        <div id="selection-actions" class="button-pair" hidden><button id="isolate" aria-pressed="false">Isolate polity</button><button id="clear-selection">Clear</button></div>
      </section>
      <div class="source-note"><span class="source-symbol">◎</span><div>Real maps. Not reconstructed video.<br><a href="https://github.com/aourednik/historical-basemaps" target="_blank" rel="noreferrer">Ourednik et al. · Historical Basemaps ↗</a></div></div>
    </aside>
    <section class="viewport" aria-label="Interactive 3D historical spacetime model">
      <div id="scene"></div><div id="axis-labels" aria-hidden="true"></div>
      <div class="viewport-top">
        <div><div class="eyebrow" id="region-caption">EUROPE & MEDITERRANEAN</div><div class="view-caption">Longitude × latitude × time</div></div>
        <div class="view-tools"><button id="orbit-view" title="3D orbit view" aria-label="3D orbit view" class="active">${icon.orbit}</button><button id="map-view" title="Look straight down at the cut" aria-label="Map view">${icon.map}</button><button id="reset-view" title="Reset camera" aria-label="Reset camera">${icon.reset}</button></div>
      </div>
      <div class="dimension-tag">Y <span>TIME</span><i></i> XZ <span>GEOGRAPHY</span></div>
      <div id="loading" role="status"><div class="loader-symbol"></div><h3>Assembling the atlas</h3><p id="loading-message">Loading historical boundaries…</p></div>
      <div id="error" role="alert" hidden><strong>The atlas couldn’t load.</strong><p id="error-message"></p><button id="retry">Try again</button></div>
      <div id="tooltip" hidden></div>
      <div class="viewport-bottom">
        <div class="interaction-hint"><span>DRAG</span> orbit <i>·</i> <span>SCROLL</span> zoom <i>·</i> <span>RIGHT DRAG</span> pan</div>
        <div id="performance" title="Live frame rate while rendering, geometry count and draw calls">Starting renderer…</div>
      </div>
      <div class="timeline">
        <div class="timeline-heading"><div><div class="eyebrow" id="timeline-caption">HORIZONTAL SECTION</div><div id="year-display">1650 <span>CE</span></div></div>
          <div class="snapshot-info"><span id="slice-status" class="live-dot"></span><span id="snapshot-label">Sourced historical boundaries</span><small id="interval-label">Snapshot-held territory, not interpolated</small></div>
          <button id="play" class="play-button" aria-label="Play timeline" disabled>${icon.play}</button>
        </div>
        <label for="year" class="sr-only">Cutting year</label><input id="year" type="range" min="1000" max="2010" value="1650" step="1" disabled>
        <div id="timeline-ticks" class="timeline-ticks"></div>
      </div>
    </section>
  </main>
  <dialog id="about"><button id="close-about" class="dialog-close" aria-label="Close data and method">×</button>
    <div class="eyebrow">PROVENANCE / NOT A SIMULATION</div><h2>A slice of the evidence.</h2>
    <p>This prototype uses <strong>44 dated global maps, 500 BCE–2010 CE</strong>, curated by André Ourednik and the Historical Basemaps contributors. The polygons are georeferenced third-party data, not traced video frames or meshes from the original Chronos model.</p>
    <h3>What the volume means</h3><p>Each map is held constant until the next available snapshot. Steps are sampling boundaries, <strong>not known dates of conquest or border change</strong>. There is no invented morphing or inferred succession. A cut at 1620 shows the 1600 map, not a reconstruction of 1620. At an exact snapshot date, the newer map is shown. Nothing is extrapolated beyond 2010.</p>
    <h3>What the colors mean</h3><p>Colors are stable hashes of the source’s SUBJECTO (authority) label, falling back to NAME. Similar colors do not imply shared identity. Identical names across snapshots are not evidence of political continuity. Click a feature for its original name and precision rating.</p>
    <h3>Limits of the evidence</h3><p>These are work-in-progress global/continental-scale maps, including cultural regions as well as states. Ancient boundaries can overlap; blank space means missing coverage, not empty land. Both resolution modes use topology-aware simplification. Projection is equirectangular (not equal-area). The neutral 2010 land footprint is orientation context, not ancient geography. Slice positions between snapshots retain the older evidence; border precision does not measure temporal certainty.</p>
    <h3>Reproducible, local, attributed</h3><p>Runtime data are served locally. Downloads are pinned to commit <code>4b5039e</code>; the importer records SHA-256 checksums. Geometry is built once in a worker; GPU plane clipping stays independent of cap generation.</p>
    <div class="source-links"><a href="https://github.com/aourednik/historical-basemaps/tree/4b5039e50d8d2464b065bd76ad6086cd4597108d" target="_blank" rel="noreferrer">Source maps ↗</a><a href="${import.meta.env.BASE_URL}data/manifest.json" target="_blank">Provenance manifest ↗</a><a href="${import.meta.env.BASE_URL}data/LICENSE.historical-basemaps.txt" target="_blank">Data license · GPL-3.0 ↗</a></div>
  </dialog>
`;

const periods = { medieval: [1000, 2010], ancient: [-500, 1000], modern: [1700, 2010], all: [-500, 2010] };
const state = {
  mode: 'time', year: 1650, position: 0.5, tilt: 35, azimuth: 0, reverse: false,
  clipping: true, showPlane: true, sectionOnly: false, selected: 0, isolated: 0,
};
let renderer, camera, controls;
let volume, land, cap, planeMesh, planeLine, axesGroup;
let model, stats;
let building = false;
let buildId = 0, sliceId = 0, sliceInFlight = false, pendingSlice = false, sliceTimer;
let playing = false, previousTime = 0, activeFrames = 0, activeMs = 0, fps = 0, lastRender = 0;
let lastCpuRenderMs = 0, idleReported = false;
let wasActive = false;
let dirty = true, hovering = 0, pointerDown;
let cameraView = 'orbit';
let axisLabels = [];
const scene = new THREE.Scene();
scene.background = new THREE.Color('#0b1018');
const root = new THREE.Group();
scene.add(root);
const worker = new Worker(new URL('./model.worker.js', import.meta.url), { type: 'module' });
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const uniforms = {
  uPlane: { value: new THREE.Vector4(0, -1, 0, 0) },
  uClip: { value: 1 }, uSelected: { value: 0 }, uHover: { value: 0 }, uIsolate: { value: 0 },
  uCap: { value: 0 },
};
const vertexShader = `
  attribute vec3 color;
  attribute float entityId;
  varying vec3 vColor;
  varying vec3 vPosition;
  varying float vEntity;
  void main() {
    vColor = mix(pow((color + 0.055) / 1.055, vec3(2.4)), color / 12.92, vec3(lessThanEqual(color, vec3(0.04045))));
    vPosition = (modelMatrix * vec4(position, 1.0)).xyz; vEntity = entityId;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
const fragmentShader = `
  uniform vec4 uPlane;
  uniform float uClip, uSelected, uHover, uIsolate, uCap;
  varying vec3 vColor;
  varying vec3 vPosition;
  varying float vEntity;
  void main() {
    if (uClip > 0.5 && dot(uPlane.xyz, vPosition) + uPlane.w < mix(0.0001, -0.0001, uCap)) discard;
    if (uIsolate > 0.5 && abs(vEntity - uIsolate) > 0.1) discard;
    vec3 n = normalize(cross(dFdx(vPosition), dFdy(vPosition)));
    float light = 0.63 + 0.28 * abs(dot(n, normalize(vec3(0.3, 0.9, 0.6))));
    vec3 color = vColor * mix(light, 1.06, uCap);
    if (uSelected > 0.5) color *= abs(vEntity - uSelected) < 0.1 ? 1.22 : 0.48;
    if (uHover > 0.5 && abs(vEntity - uHover) < 0.1) color = mix(color, vec3(0.95), 0.25);
    gl_FragColor = vec4(color, 1.0);
    #include <colorspace_fragment>
  }
`;

function createMaterial(isCap = false) {
  return new THREE.ShaderMaterial({
    uniforms: { ...uniforms, uCap: { value: isCap ? 1 : 0 } },
    vertexShader, fragmentShader, side: THREE.DoubleSide,
    polygonOffset: isCap, polygonOffsetFactor: isCap ? -2 : 0, polygonOffsetUnits: isCap ? -2 : 0,
  });
}
const volumeMaterial = createMaterial();
const capMaterial = createMaterial(true);

function geometryFrom(buffers) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(buffers.positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(buffers.colors, 3, true));
  geometry.setAttribute('entityId', new THREE.BufferAttribute(buffers.entityIds, 1));
  geometry.setAttribute('recordId', new THREE.BufferAttribute(buffers.recordIds, 1));
  geometry.setIndex(new THREE.BufferAttribute(buffers.indices, 1));
  geometry.computeBoundingSphere();
  return geometry;
}

function disposeMesh(mesh, disposeMaterial = false) {
  if (!mesh) return;
  root.remove(mesh);
  mesh.geometry?.dispose();
  if (disposeMaterial) mesh.material?.dispose();
}

function fail(message) {
  building = false;
  playing = false;
  $('play').innerHTML = icon.play;
  $('play').setAttribute('aria-label', 'Play timeline');
  $('loading').hidden = true;
  $('error-message').textContent = message;
  $('error').hidden = false;
  setBusy(false);
}

function setBusy(busy) {
  for (const id of ['region', 'period', 'quality', 'year', 'play', 'entity-search']) $(id).disabled = busy || !model;
}

function requestBuild() {
  stopPlayback();
  building = true;
  if (window.__chronos) window.__chronos.ready = false;
  buildId++;
  sliceId++;
  pendingSlice = false;
  clearTimeout(sliceTimer);
  $('error').hidden = true;
  $('loading').hidden = false;
  setBusy(true);
  const [start, end] = periods[$('period').value];
  state.year = Math.max(start, Math.min(end, state.year));
  $('year').min = start;
  $('year').max = end;
  $('year').value = state.year;
  $('region-caption').textContent = REGIONS[$('region').value].label.toUpperCase();
  clearSelection();
  worker.postMessage({
    type: 'build', requestId: buildId,
    config: { bounds: REGIONS[$('region').value].bounds, start, end, quality: $('quality').value },
  });
}

function plane() {
  return planeFor({
    ...state,
    position: state.mode === 'time' ? state.year : state.mode === 'oblique'
      ? (state.year - model.dimensions.start) / (model.dimensions.end - model.dimensions.start) : state.position,
  }, model.dimensions);
}

function queueSlice(immediate = false) {
  if (!model) return;
  if (syncTemporalCap()) return;
  sliceId++;
  pendingSlice = true;
  if (window.__chronos) window.__chronos.sectionPending = true;
  if (cap) cap.visible = false;
  $('slice-status').classList.add('pending');
  clearTimeout(sliceTimer);
  if (immediate) sendSlice();
  else sliceTimer = setTimeout(sendSlice, playing ? 160 : 90);
}

function syncTemporalCap() {
  if (!cap || state.mode !== 'time' || cap.userData.mode !== 'time' || pendingSlice || sliceInFlight) return false;
  const sourceYear = snapshotAt(model.sourceYears.map(year => ({ year })), state.year)?.year;
  if (sourceYear !== cap.userData.sourceYear) return false;
  cap.position.y = (state.year - cap.userData.year) / (model.dimensions.end - model.dimensions.start) * model.dimensions.height;
  cap.visible = state.clipping || state.sectionOnly;
  $('slice-status').classList.remove('pending');
  dirty = true;
  return true;
}

function sendSlice() {
  if (sliceInFlight || !pendingSlice || !model) return;
  pendingSlice = false;
  sliceInFlight = true;
  worker.postMessage({ type: 'slice', requestId: sliceId, config: { plane: plane(), mode: state.mode, year: state.year, modelId: buildId } });
}

worker.onmessage = ({ data }) => {
  if (data.type === 'progress') {
    $('loading-message').textContent = data.message;
  } else if (data.type === 'error') {
    sliceInFlight = false;
    fail(data.message);
  } else if (data.type === 'model') {
    if (data.requestId !== buildId) return;
    building = false;
    model = data;
    stats = data.stats;
    disposeMesh(volume);
    disposeMesh(land, true);
    disposeMesh(cap);
    cap = null;
    volume = new THREE.Mesh(geometryFrom(data.buffers), volumeMaterial);
    volume.geometry.boundsTree = MeshBVH.deserialize(data.bvh, volume.geometry);
    volume.raycast = acceleratedRaycast;
    root.add(volume);
    land = new THREE.Mesh(geometryFrom(data.landBuffers), new THREE.MeshBasicMaterial({ color: '#25323d', side: THREE.DoubleSide }));
    root.add(land);
    makeAxes();
    resetCamera();
    updateTimeline();
    updateCut();
    queueSlice(true);
    $('loading').hidden = true;
    setBusy(false);
    dirty = true;
  } else if (data.type === 'slice') {
    sliceInFlight = false;
    if (data.requestId === sliceId && data.modelId === buildId) {
      disposeMesh(cap);
      cap = new THREE.Mesh(geometryFrom(data.buffers), capMaterial);
      cap.userData = { mode: data.mode, year: data.year, sourceYear: data.sourceYear };
      cap.raycast = THREE.Mesh.prototype.raycast;
      cap.renderOrder = 1;
      root.add(cap);
      cap.visible = state.clipping || state.sectionOnly;
      model.visibleEntities = data.visible;
      model.sliceMs = data.sliceMs;
      $('slice-status').classList.remove('pending');
      dirty = true;
    }
    if (pendingSlice) sendSlice();
  }
};
worker.onerror = event => fail(`Model worker failed: ${event.message}`);

function makeAxes() {
  if (axesGroup) {
    root.remove(axesGroup);
    axesGroup.traverse(o => { o.geometry?.dispose(); o.material?.dispose(); });
  }
  axesGroup = new THREE.Group();
  root.add(axesGroup);
  $('axis-labels').replaceChildren();
  axisLabels = [];
  const { width: w, depth: d, height: h, start, end, bounds } = model.dimensions;
  const floor = -h * 0.015;
  const vertices = [];
  for (let i = 0; i <= 8; i++) {
    const x = -w / 2 + w * i / 8;
    const z = -d / 2 + d * i / 8;
    vertices.push(x, floor, -d / 2, x, floor, d / 2);
    vertices.push(-w / 2, floor, z, w / 2, floor, z);
  }
  vertices.push(-w / 2 - w * 0.035, 0, d / 2, -w / 2 - w * 0.035, h, d / 2);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  axesGroup.add(new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ color: '#31404d', transparent: true, opacity: 0.6 })));
  const addLabel = (text, position, className = '') => {
    const element = document.createElement('span');
    element.className = `axis-label ${className}`;
    element.textContent = text;
    $('axis-labels').append(element);
    axisLabels.push({ element, position: new THREE.Vector3(...position) });
  };
  for (let i = 0; i <= 4; i++) {
    const year = i === 4 ? end : Math.round((start + (end - start) * i / 4) / 50) * 50;
    addLabel(yearLabel(year), [-w / 2 - w * 0.04, (year - start) / (end - start) * h, d / 2], 'year-axis');
  }
  addLabel('N', [0, floor, -d / 2 - d * 0.06], 'north-label');
  addLabel(`${bounds[0]}° → ${bounds[2]}° LONGITUDE`, [0, floor, d / 2 + d * 0.08], 'geo-axis');
  const markers = document.createDocumentFragment();
  const dates = model.records.map(r => r.year);
  const sourceYears = [...new Set(dates)].sort((a, b) => a - b);
  for (const year of sourceYears) {
    const marker = document.createElement('button');
    marker.className = 'snapshot-tick';
    marker.style.left = `${(year - start) / (end - start) * 100}%`;
    marker.title = `Jump to source map: ${yearLabel(year)}`;
    marker.setAttribute('aria-label', marker.title);
    marker.addEventListener('click', () => { state.year = year; stopPlayback(); updateTimeline(); updateCut(); queueSlice(true); });
    markers.append(marker);
  }
  for (const [year, value] of [[start, 0], [Math.round((start + end) / 2), 50], [end, 100]]) {
    const label = document.createElement('span');
    label.textContent = yearLabel(year);
    label.style.left = `${value}%`;
    label.className = `tick-label tick-${value}`;
    markers.append(label);
  }
  $('timeline-ticks').replaceChildren(markers);
}

function updatePlaneMesh() {
  disposeMesh(planeMesh, true);
  disposeMesh(planeLine, true);
  const p = plane();
  const { width, depth, height } = model.dimensions;
  const margin = width * 0.025;
  const corners = [];
  for (const x of [-width / 2 - margin, width / 2 + margin])
    for (const y of [-margin, height + margin])
      for (const z of [-depth / 2 - margin, depth / 2 + margin]) corners.push(new THREE.Vector3(x, y, z));
  const edges = [[0, 1], [0, 2], [0, 4], [1, 3], [1, 5], [2, 3], [2, 6], [3, 7], [4, 5], [4, 6], [5, 7], [6, 7]];
  const points = [];
  for (const [i, j] of edges) {
    const a = signedDistance(corners[i].toArray(), p);
    const b = signedDistance(corners[j].toArray(), p);
    if (a * b <= 0 && Math.abs(a - b) > 1e-10) {
      const point = corners[i].clone().lerp(corners[j], a / (a - b));
      if (!points.some(q => q.distanceToSquared(point) < 1e-10)) points.push(point);
    }
  }
  if (points.length < 3) { planeMesh = null; planeLine = null; return; }
  const center = points.reduce((c, v) => c.add(v), new THREE.Vector3()).divideScalar(points.length);
  const normal = new THREE.Vector3(...p.slice(0, 3));
  const u = new THREE.Vector3().crossVectors(normal, Math.abs(normal.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0)).normalize();
  const v = new THREE.Vector3().crossVectors(normal, u);
  const angle = point => { const delta = point.clone().sub(center); return Math.atan2(delta.dot(v), delta.dot(u)); };
  points.sort((a, b) => angle(a) - angle(b));
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const indices = [];
  for (let i = 1; i < points.length - 1; i++) indices.push(0, i, i + 1);
  geometry.setIndex(indices);
  planeMesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: '#9de3d5', side: THREE.DoubleSide, transparent: true, opacity: 0.055, depthWrite: false }));
  planeMesh.renderOrder = 2;
  root.add(planeMesh);
  planeLine = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color: '#94d9cc', transparent: true, opacity: 0.7, depthTest: false }));
  planeLine.renderOrder = 3;
  root.add(planeLine);
  planeMesh.visible = planeLine.visible = state.showPlane;
}

function updateCut() {
  if (!model) return;
  uniforms.uPlane.value.fromArray(plane());
  uniforms.uClip.value = state.clipping && !state.sectionOnly ? 1 : 0;
  volume.visible = !state.sectionOnly;
  if (cap) {
    cap.visible = !pendingSlice && !sliceInFlight && (state.clipping || state.sectionOnly);
    syncTemporalCap();
  }
  updatePlaneMesh();
  const descriptions = {
    time: `Horizontal cut. ${state.reverse ? 'Later time is retained above' : 'Earlier time is retained below'} the plane.`,
    longitude: `North–south cut, swept through time. ${state.reverse ? 'East' : 'West'} is retained.`,
    latitude: `East–west cut, swept through time. ${state.reverse ? 'North' : 'South'} is retained.`,
    oblique: 'A tilted spacetime section. Moving the year shifts its center; it does not represent a single date.',
  };
  $('cut-description').textContent = descriptions[state.mode];
  $('spatial-controls').hidden = !['longitude', 'latitude'].includes(state.mode);
  $('oblique-controls').hidden = state.mode !== 'oblique';
  const bounds = model.dimensions.bounds;
  const value = state.mode === 'longitude' ? bounds[0] + state.position * (bounds[2] - bounds[0]) : bounds[1] + state.position * (bounds[3] - bounds[1]);
  $('spatial-value').textContent = `${Math.abs(value).toFixed(1)}°${state.mode === 'longitude' ? value < 0 ? 'W' : 'E' : value < 0 ? 'S' : 'N'}`;
  if (cameraView === 'map') fitSectionCamera();
  dirty = true;
}

function updateTimeline() {
  const year = Math.round(state.year);
  $('year').value = year;
  $('year-display').replaceChildren(document.createTextNode(`${Math.abs(year)} `));
  const era = document.createElement('span');
  era.textContent = year < 0 ? 'BCE' : 'CE';
  $('year-display').append(era);
  $('timeline-caption').textContent = state.mode === 'time' ? 'HORIZONTAL SECTION' : state.mode === 'oblique' ? 'OBLIQUE SECTION · CENTER YEAR' : 'SPATIAL SECTION · ALL DATES';
  const sourceYears = model?.sourceYears ?? [];
  const source = snapshotAt(sourceYears.map(year => ({ year })), state.year);
  if (state.mode === 'time' || state.mode === 'oblique') {
    $('snapshot-label').textContent = source ? `Source map · ${yearLabel(source.year)}` : 'No source coverage';
    const next = sourceYears.find(y => y > (source?.year ?? -Infinity));
    $('interval-label').textContent = state.mode === 'oblique' ? 'Dates vary across the tilted plane' : next ? `Held until ${yearLabel(next)} · not verified change dates` : 'Final dated snapshot · no extrapolation';
  } else {
    $('snapshot-label').textContent = `${stats?.snapshots ?? 0} dated maps in this time window`;
    $('interval-label').textContent = 'A geographical transect through the swept volume';
  }
}

function resetCamera() {
  if (!model || !camera) return;
  cameraView = 'orbit';
  $('orbit-view').classList.add('active');
  $('map-view').classList.remove('active');
  const { width, depth, height } = model.dimensions;
  const center = new THREE.Vector3(0, height * 0.4, 0);
  const radius = Math.hypot(width, depth, height) * 0.5;
  const fov = camera.fov * Math.PI / 180;
  const horizontal = 2 * Math.atan(Math.tan(fov / 2) * camera.aspect);
  const distance = radius / Math.sin(Math.min(fov, horizontal) / 2) * 1.03;
  const direction = new THREE.Vector3(0.95, 0.88, 1.25).normalize();
  camera.up.set(0, 1, 0);
  camera.position.copy(center).addScaledVector(direction, distance);
  controls.target.copy(center);
  controls.minDistance = width * 0.08;
  controls.maxDistance = width * 12;
  camera.near = width / 2000;
  camera.far = width * 40;
  camera.updateProjectionMatrix();
  controls.update();
  dirty = true;
}

function fitSectionCamera() {
  if (!model || !camera) return;
  const { width, depth, height, start, end } = model.dimensions;
  const p = plane();
  const normal = new THREE.Vector3(...p.slice(0, 3));
  let center = new THREE.Vector3(0, height / 2, 0);
  center.addScaledVector(normal, -(normal.dot(center) + p[3]));
  const faceWidth = state.mode === 'longitude' ? depth : width;
  const faceHeight = state.mode === 'time' ? depth : state.mode === 'oblique' ? Math.hypot(depth, height) : height;
  const distance = Math.max(faceWidth / camera.aspect, faceHeight) / (2 * Math.tan(camera.fov * Math.PI / 360)) * 1.22;
  if (state.mode === 'time') center.y = (state.year - start) / (end - start) * height;
  // Look from the removed half-space so the retained volume cannot obscure its own section.
  camera.position.copy(center).addScaledVector(normal, -distance);
  camera.up.set(0, 1, 0);
  if (Math.abs(normal.y) > 0.98) camera.up.set(0, 0, -1);
  controls.target.copy(center);
  controls.update();
  dirty = true;
}

function stopPlayback() {
  playing = false;
  $('play').innerHTML = icon.play;
  $('play').setAttribute('aria-label', 'Play timeline');
}

function escapeText(value) {
  return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

function selectEntity(id, record) {
  const entity = model.entities.find(e => e.id === id);
  if (!entity) return;
  state.selected = id;
  state.isolated = 0;
  uniforms.uSelected.value = id;
  uniforms.uIsolate.value = 0;
  $('isolate').textContent = 'Isolate polity';
  $('isolate').setAttribute('aria-pressed', 'false');
  const precision = { 1: 'Approximate', 2: 'Moderately precise', 3: 'International-law boundary' };
  $('inspector').innerHTML = `<div class="selected-name"><span style="background:rgb(${entity.color.join(',')})"></span>${escapeText(record?.name ?? entity.name)}</div>
    ${record && record.name !== entity.name ? `<p class="authority">Authority: ${escapeText(entity.name)}</p>` : ''}
    <dl><dt>Source snapshot</dt><dd>${record ? yearLabel(record.year) : 'Multiple maps'}</dd>
    <dt>Spatial precision</dt><dd>${escapeText(record ? precision[record.precision] ?? 'Not specified' : 'Varies by source')}</dd></dl>
    ${record ? `<a class="source-map-link" href="https://github.com/aourednik/historical-basemaps/blob/4b5039e50d8d2464b065bd76ad6086cd4597108d/geojson/world_${record.year < 0 ? `bc${-record.year}` : record.year}.geojson" target="_blank" rel="noreferrer">Open this source map ↗</a>` : ''}`;
  $('selection-actions').hidden = false;
  $('search-results').hidden = true;
  dirty = true;
}

function clearSelection() {
  state.selected = state.isolated = 0;
  uniforms.uSelected.value = uniforms.uIsolate.value = 0;
  $('inspector').innerHTML = '<p class="empty-selection">Select a territory in the model<br>to inspect its source snapshot.</p>';
  $('selection-actions').hidden = true;
  $('entity-search').value = '';
  $('search-results').hidden = true;
  dirty = true;
}

function pick(event) {
  if (!model || !volume) return null;
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
  raycaster.setFromCamera(mouse, camera);
  const objects = [volume, cap].filter(mesh => mesh?.visible);
  const hits = raycaster.intersectObjects(objects, false);
  const p = plane();
  return hits.find(hit => {
    if (state.clipping && !state.sectionOnly && signedDistance(hit.point.toArray(), p) < -0.001) return false;
    const vertex = hit.object.geometry.index.getX(hit.faceIndex * 3);
    const id = hit.object.geometry.getAttribute('entityId').getX(vertex);
    return !state.isolated || id === state.isolated;
  });
}

function recordFromHit(hit) {
  const geometry = hit.object.geometry;
  const index = geometry.index.getX(hit.faceIndex * 3);
  return model.records[geometry.getAttribute('recordId').getX(index)];
}

function initialize() {
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: false });
  } catch (error) {
    fail(`WebGL2 is required for this viewer. ${error.message}`);
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  $('scene').append(renderer.domElement);
  camera = new THREE.PerspectiveCamera(36, 1, 0.01, 10000);
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.09;
  controls.addEventListener('change', () => { dirty = true; });
  controls.addEventListener('start', () => {
    cameraView = 'free';
    $('orbit-view').classList.remove('active');
    $('map-view').classList.remove('active');
  });
  new ResizeObserver(entries => {
    const { width, height } = entries[0].contentRect;
    renderer.setSize(width, height);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    if (cameraView === 'map') fitSectionCamera();
    dirty = true;
  }).observe($('scene'));
  renderer.domElement.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    fail('The graphics context was lost. Reload the page, or reduce geometry detail and close other GPU-heavy tabs.');
  });
  renderer.domElement.addEventListener('pointerdown', event => { pointerDown = [event.clientX, event.clientY]; });
  renderer.domElement.addEventListener('pointerup', event => {
    if (event.button !== 0 || !pointerDown || Math.hypot(event.clientX - pointerDown[0], event.clientY - pointerDown[1]) > 5) return;
    const hit = pick(event);
    if (hit) { const record = recordFromHit(hit); selectEntity(record.entityId, record); }
    else clearSelection();
  });
  let lastHover = 0;
  renderer.domElement.addEventListener('pointermove', event => {
    if (event.buttons || performance.now() - lastHover < 70) return;
    lastHover = performance.now();
    const hit = pick(event);
    if (hit) {
      const record = recordFromHit(hit);
      hovering = record.entityId;
      $('tooltip').textContent = `${record.name} · ${yearLabel(record.year)}`;
      const rect = $('scene').getBoundingClientRect();
      $('tooltip').style.left = `${Math.min(event.clientX - rect.left + 14, rect.width - 245)}px`;
      $('tooltip').style.top = `${event.clientY - rect.top - 38}px`;
      $('tooltip').hidden = false;
    } else {
      hovering = 0;
      $('tooltip').hidden = true;
    }
    uniforms.uHover.value = hovering;
    dirty = true;
  });
  renderer.domElement.addEventListener('pointerleave', () => {
    $('tooltip').hidden = true;
    uniforms.uHover.value = 0;
    dirty = true;
  });
  requestBuild();
  requestAnimationFrame(animate);
}

function animate(time) {
  requestAnimationFrame(animate);
  const delta = previousTime ? Math.min((time - previousTime) / 1000, 0.1) : 0;
  previousTime = time;
  controls.update();
  if (playing && model) {
    const { start, end } = model.dimensions;
    state.year += delta * (end - start) / 35;
    if (state.year >= end) { state.year = end; stopPlayback(); }
    updateTimeline();
    uniforms.uPlane.value.fromArray(plane());
    // Keep shader clipping frame-synchronous; request integer-year cap updates at a bounded cadence.
    if (time - (model.lastPlaybackSlice ?? 0) > 180) {
      state.year = Math.max(start, state.year);
      model.lastPlaybackSlice = time;
      updateCut();
      queueSlice(true);
    } else if (cap && !syncTemporalCap()) cap.visible = false;
    dirty = true;
  }
  if (!dirty) {
    wasActive = false;
    if (model && !idleReported && time - lastRender > 300) {
      reportPerformance(true);
      idleReported = true;
    }
    return;
  }
  const renderStart = performance.now();
  renderer.render(scene, camera);
  for (const label of axisLabels) {
    const point = label.position.clone().project(camera);
    label.element.style.left = `${(point.x + 1) / 2 * $('scene').clientWidth}px`;
    label.element.style.top = `${(1 - point.y) / 2 * $('scene').clientHeight}px`;
    label.element.hidden = point.z > 1 || point.z < -1;
  }
  lastCpuRenderMs = performance.now() - renderStart;
  const gap = time - lastRender;
  if (wasActive && lastRender) { activeFrames++; activeMs += gap; }
  else { activeFrames = 0; activeMs = 0; fps = 0; }
  if (activeFrames >= 10) {
    fps = Math.round(activeFrames * 1000 / activeMs);
    if (activeFrames > 60) { activeFrames = 0; activeMs = 0; }
  }
  lastRender = time;
  wasActive = true;
  idleReported = false;
  reportPerformance(false);
  // OrbitControls emits change events while damping; leave idle scenes unrendered.
  dirty = playing;
}

function reportPerformance(idle) {
  if (!stats) return;
  const triangles = renderer.info.render.triangles;
  $('performance').textContent = `${idle ? 'Idle' : fps ? `${fps} fps` : 'Interactive'} · ${Intl.NumberFormat('en', { notation: 'compact' }).format(triangles)} triangles · ${renderer.info.render.calls} draws`;
  $('performance').title = `${lastCpuRenderMs.toFixed(1)} ms CPU render submission (not GPU time) · ${stats.buildMs} ms worker build including load · ${model.sliceMs ?? '…'} ms last section · ${(stats.geometryBytes / 1e6).toFixed(1)} MB packed volume · idle rendering is suspended`;
  window.__chronos = {
    ready: !building, ...stats, fps, idle, cpuRenderMs: lastCpuRenderMs, draws: renderer.info.render.calls,
    renderedTriangles: triangles, capTriangles: cap?.geometry.index.count / 3 || 0,
    sliceMs: model.sliceMs, selected: state.selected, isolated: state.isolated, mode: state.mode,
    year: state.year, modelId: model.requestId, sectionPending: building || pendingSlice || sliceInFlight, capVisible: cap?.visible ?? false,
  };
}

for (const id of ['region', 'period', 'quality']) $(id).addEventListener('change', requestBuild);
for (const button of document.querySelectorAll('[data-mode]')) button.addEventListener('click', () => {
  stopPlayback();
  state.mode = button.dataset.mode;
  for (const b of document.querySelectorAll('[data-mode]')) {
    b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', String(b === button));
  }
  updateTimeline(); updateCut(); queueSlice(true);
});
$('year').addEventListener('input', () => {
  stopPlayback(); state.year = Number($('year').value); updateTimeline(); updateCut(); queueSlice();
});
$('spatial-position').addEventListener('input', () => { state.position = Number($('spatial-position').value); updateCut(); queueSlice(); });
for (const id of ['tilt', 'azimuth']) $(id).addEventListener('input', () => {
  state[id] = Number($(id).value); $(`${id}-value`).textContent = `${state[id]}°`; updateCut(); queueSlice();
});
$('clip').addEventListener('change', () => { state.clipping = $('clip').checked; updateCut(); });
$('show-plane').addEventListener('change', () => { state.showPlane = $('show-plane').checked; updateCut(); });
$('flip').addEventListener('click', () => { state.reverse = !state.reverse; $('flip').classList.toggle('active', state.reverse); updateCut(); queueSlice(true); });
$('section-only').addEventListener('click', () => {
  state.sectionOnly = !state.sectionOnly;
  $('section-only').classList.toggle('active', state.sectionOnly);
  $('section-only').setAttribute('aria-pressed', String(state.sectionOnly));
  updateCut(); dirty = true;
});
$('map-view').addEventListener('click', () => {
  cameraView = 'map'; $('map-view').classList.add('active'); $('orbit-view').classList.remove('active'); fitSectionCamera();
});
$('orbit-view').addEventListener('click', resetCamera);
$('reset-view').addEventListener('click', resetCamera);
$('play').addEventListener('click', () => {
  if (playing) { stopPlayback(); queueSlice(true); return; }
  if (state.year >= model.dimensions.end) state.year = model.dimensions.start;
  playing = true;
  $('play').innerHTML = icon.pause;
  $('play').setAttribute('aria-label', 'Pause timeline');
});
$('clear-selection').addEventListener('click', clearSelection);
$('isolate').addEventListener('click', () => {
  state.isolated = state.isolated ? 0 : state.selected;
  uniforms.uIsolate.value = state.isolated;
  $('isolate').textContent = state.isolated ? 'Show all polities' : 'Isolate polity';
  $('isolate').setAttribute('aria-pressed', String(Boolean(state.isolated)));
  dirty = true;
});
$('entity-search').addEventListener('input', () => {
  const query = $('entity-search').value.trim().toLocaleLowerCase();
  $('search-results').replaceChildren();
  $('search-results').hidden = !query;
  if (!query) return;
  const matches = model.entities.filter(e => e.name.toLocaleLowerCase().includes(query)).slice(0, 8);
  if (!matches.length) $('search-results').textContent = 'No authority with that name in this view.';
  for (const entity of matches) {
    const button = document.createElement('button');
    button.textContent = entity.name;
    button.addEventListener('click', () => selectEntity(entity.id));
    $('search-results').append(button);
  }
});
$('about-button').addEventListener('click', () => $('about').showModal());
$('close-about').addEventListener('click', () => $('about').close());
$('about').addEventListener('click', event => { if (event.target === $('about')) $('about').close(); });
$('retry').addEventListener('click', () => renderer ? requestBuild() : location.reload());
document.addEventListener('visibilitychange', () => { if (document.hidden) stopPlayback(); dirty = true; });
initialize();
