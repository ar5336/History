import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { gzipSync } from 'node:zlib';
import mapshaper from 'mapshaper';

const commit = '4b5039e50d8d2464b065bd76ad6086cd4597108d';
const repository = 'https://github.com/aourednik/historical-basemaps';
const base = `https://raw.githubusercontent.com/aourednik/historical-basemaps/${commit}`;
const years = [-500, -400, -323, -300, -200, -100, -1,
  100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1279,
  1300, 1400, 1492, 1500, 1530, 1600, 1650, 1700, 1715, 1783, 1800,
  1815, 1878, 1880, 1900, 1914, 1920, 1930, 1938, 1945, 1960, 1994, 2000, 2010];
const cache = new URL(`../.cache/historical-basemaps/${commit}/`, import.meta.url);
const output = new URL('../public/data/', import.meta.url);
const sha256 = value => createHash('sha256').update(value).digest('hex');
await mkdir(cache, { recursive: true });
await mkdir(output, { recursive: true });

async function download(path) {
  const cached = new URL(path.replaceAll('/', '_'), cache);
  try {
    return await readFile(cached);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const response = await fetch(`${base}/${path}`);
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
  const bytes = Buffer.from(await response.arrayBuffer());
  await writeFile(cached, bytes);
  return bytes;
}

function simplify(bytes, interval) {
  return new Promise((resolve, reject) => {
    mapshaper.applyCommands(
      `-i input.geojson -simplify dp planar interval=${interval} keep-shapes -o output.geojson format=geojson precision=0.001`,
      { 'input.geojson': bytes.toString() },
      (error, files) => error ? reject(error) : resolve(JSON.parse(files['output.geojson'])),
    );
  });
}

const snapshots = [];
const overview = [];
const files = [];
for (const year of years) {
  const filename = `world_${year < 0 ? `bc${-year}` : year}.geojson`;
  const path = `geojson/${filename}`;
  const bytes = await download(path);
  const convert = collection => collection.features.flatMap(feature => {
    if (!feature.geometry) return [];
    const { type, coordinates } = feature.geometry;
    if (type !== 'Polygon' && type !== 'MultiPolygon') throw new Error(`Unsupported geometry: ${type}`);
    const p = feature.properties;
    return [{
      name: p.NAME?.trim() || null,
      authority: p.SUBJECTO?.trim() || p.NAME?.trim() || null,
      precision: Number(p.BORDERPRECISION) || null,
      polygons: type === 'Polygon' ? [coordinates] : coordinates,
    }];
  });
  const features = convert(await simplify(bytes, 0.12));
  snapshots.push({ year, features });
  overview.push({ year, features: convert(await simplify(bytes, 0.5)) });
  files.push({ year, path, sha256: sha256(bytes), features: features.length });
  console.log(`${year}: ${features.length} features`);
}

const data = Buffer.from(JSON.stringify({ version: 1, snapshots }));
const compressed = gzipSync(data, { level: 9, mtime: 0 });
await writeFile(new URL('boundaries.json.gz', output), compressed);
const overviewBytes = gzipSync(Buffer.from(JSON.stringify({ version: 1, snapshots: overview })), { level: 9, mtime: 0 });
await writeFile(new URL('boundaries-overview.json.gz', output), overviewBytes);
await writeFile(new URL('LICENSE.historical-basemaps.txt', output), await download('LICENSE'));
const manifest = {
  title: 'Historical boundaries of world countries and cultural regions',
  author: 'André Ourednik and historical-basemaps contributors',
  repository, commit, license: 'GPL-3.0', crs: 'EPSG:4326',
  transformation: 'Mapshaper topology-aware planar Douglas–Peucker simplification, interval 0.12 degrees (detail) / 0.5 degrees (overview), keep-shapes; coordinates rounded to 0.001 degrees. Names, authority and border precision retained.',
  temporalModel: 'Right-continuous snapshot hold: each dated map is extruded until the next available map. These intervals are NOT independently verified dates of territorial change. No data are extrapolated after the last snapshot.',
  caveats: 'Curated, work-in-progress global/continental-scale maps, not an authoritative historical GIS. Ancient cultural areas may overlap; blank areas are unknown, not uninhabited. Same-name coloring is not proof of political continuity.',
  data: { file: 'boundaries.json.gz', bytes: compressed.length, uncompressedBytes: data.length, sha256: sha256(compressed) },
  overview: { file: 'boundaries-overview.json.gz', bytes: overviewBytes.length, sha256: sha256(overviewBytes), simplificationDegrees: 0.5 },
  files,
};
await writeFile(new URL('manifest.json', output), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Wrote ${snapshots.length} snapshots, ${(compressed.length / 1e6).toFixed(2)} MB gzip`);
